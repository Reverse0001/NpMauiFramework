﻿using System.Text.RegularExpressions;

string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

// Navigate up to the solution directory, which is two levels above the script's current directory.
// This assumes that currentDirectory returns something similar to ".../NpMauiApp1/NpMauiAppTemp1/bin/Debug/net6.0/"
string solutionDirectory = Path.GetFullPath(Path.Combine(currentDirectory, "..", "..", "..", ".."));
string ph = Path.GetFullPath(Path.Combine(currentDirectory, "..", "..", ".."));
string solutionName = new DirectoryInfo(solutionDirectory).Name;

// Set the paths to the ViewModel directory and MauiProgram.cs using the solution directory as the base
string viewModelDirectory = Path.Combine(solutionDirectory, solutionName, "ViewModels");
string mauiProgramFile = Path.Combine(solutionDirectory, solutionName, "MauiProgram.cs");
string[] viewModelFiles = Directory.GetFiles(viewModelDirectory, "*View.cs");
string serviceDirectory = Path.Combine(solutionDirectory, solutionName, "Services");
string appShellFile = Path.Combine(solutionDirectory, solutionName, "AppShell.xaml.cs");

string mauiProgramFileContent = File.ReadAllText(mauiProgramFile);

bool changesMade = false;
foreach (string file in viewModelFiles)
{
    string viewModelName = Path.GetFileNameWithoutExtension(file);

    // Check if ViewModel is already registered
    string viewModelRegistrationPattern = $@"builder\.Services\.AddTransient<{viewModelName}Model>\(\)";
    string viewRegistrationPattern = $@"builder\.Services\.AddSingleton<{viewModelName}>\(\)";

    // Locate the 'RegisterViewsAndViewModels' method
    string registerViewsAndViewModelsMethodPattern = @"private static MauiAppBuilder RegisterViewsAndViewModels\(this MauiAppBuilder builder\)";
    Match match = Regex.Match(mauiProgramFileContent, registerViewsAndViewModelsMethodPattern);

    if (match.Success)
    {
        // Find the location to insert the registration code within the 'RegisterViewsAndViewModels' method
        int methodStartIndex = match.Index;
        int methodEndIndex = mauiProgramFileContent.IndexOf("return builder;", methodStartIndex, StringComparison.Ordinal);

        if (methodEndIndex > methodStartIndex) // Ensure we're within the method
        {
            // Prepare the registration code for the ViewModel
            string viewModelRegistrationCode = $"\n            builder.Services.AddTransient<{viewModelName}Model>();";
            // Prepare the registration code for the View
            string viewRegistrationCode = $"\n            builder.Services.AddSingleton<{viewModelName}>();";

            // Insert the ViewModel registration if it's not already there
            if (!Regex.IsMatch(mauiProgramFileContent, viewModelRegistrationPattern))
            {
                mauiProgramFileContent = mauiProgramFileContent.Insert(methodEndIndex, viewModelRegistrationCode);
                changesMade = true;
                methodEndIndex += viewModelRegistrationCode.Length; // Update the index for the next insertion
            }

            // Insert the View registration if it's not already there
            if (!Regex.IsMatch(mauiProgramFileContent, viewRegistrationPattern))
            {
                mauiProgramFileContent = mauiProgramFileContent.Insert(methodEndIndex, viewRegistrationCode);
                changesMade = true;
                // No need to update methodEndIndex since it's the last insertion
            }
        }

    }
    if (changesMade)
    {
        File.WriteAllText(mauiProgramFile, mauiProgramFileContent);
    }
}

string[] serviceFiles = Directory.GetFiles(serviceDirectory, "*.cs");
foreach (string file in serviceFiles)
{
    string serviceName = Path.GetFileNameWithoutExtension(file);

    // Check if Service is already registered
    string serviceRegistrationPattern = $@"builder\.Services\.AddTransient<{serviceName}>\(\)";

    // Locate the 'RegisterServices' method
    string registerServicesMethodPattern = @"private static MauiAppBuilder RegisterServices\(this MauiAppBuilder builder\)";
    Match match = Regex.Match(mauiProgramFileContent, registerServicesMethodPattern);

    if (match.Success)
    {
        // Find the location to insert the registration code within the 'RegisterServices' method
        int methodStartIndex = match.Index;
        int methodEndIndex = mauiProgramFileContent.IndexOf("return builder;", methodStartIndex, StringComparison.Ordinal);

        if (methodEndIndex > methodStartIndex) // Ensure we're within the method
        {
            // Prepare the registration code for the Service
            string serviceRegistrationCode = $"\n            builder.Services.AddTransient<{serviceName}>();";

            // Insert the Service registration if it's not already there
            if (!Regex.IsMatch(mauiProgramFileContent, serviceRegistrationPattern))
            {
                mauiProgramFileContent = mauiProgramFileContent.Insert(methodEndIndex, serviceRegistrationCode);
                changesMade = true;
            }
        }
    }
    // Write the updated content back to the MauiProgram file
    if (changesMade)
    {
        File.WriteAllText(mauiProgramFile, mauiProgramFileContent);
    }
}

string appShellFileContent = File.ReadAllText(appShellFile);
foreach (string file in viewModelFiles)
{
    string viewName = Path.GetFileNameWithoutExtension(file);
    string routeRegistrationPattern = $@"Routing\.RegisterRoute\(nameof\({viewName}\), typeof\({viewName}\)\);";

    // Check if the route for the View is already registered
    if (!Regex.IsMatch(appShellFileContent, routeRegistrationPattern))
    {
        // Find the location to insert the routing registration code
        string routeRegistrationInsertionPoint = "InitializeComponent();";
        int insertionIndex = appShellFileContent.IndexOf(routeRegistrationInsertionPoint) + routeRegistrationInsertionPoint.Length;

        if (insertionIndex > routeRegistrationInsertionPoint.Length)
        {
            // Generate the routing registration code for the View
            string routingRegistrationCode = $"\n            Routing.RegisterRoute(nameof({viewName}), typeof({viewName}));";
            appShellFileContent = appShellFileContent.Insert(insertionIndex, routingRegistrationCode);
            changesMade = true;
        }
    }
}

string viewsDirectory = Path.Combine(solutionDirectory, solutionName, "Views");
string[] viewXamlFiles = Directory.GetFiles(viewsDirectory, "*.xaml");
string[] viewCodeBehindFiles = Directory.GetFiles(viewsDirectory, "*.xaml.cs");

// Process .xaml files for correct ViewModel namespace
foreach (string file in viewXamlFiles)
{
    string xamlContent = File.ReadAllText(file);
    string wrongViewModelPathPattern = @"clr-namespace:" + solutionName + "\\.Views\\.ViewModels";
    string correctViewModelPath = "clr-namespace:" + solutionName + ".ViewModels";

    // Replace wrong namespace path if it's found
    if (Regex.IsMatch(xamlContent, wrongViewModelPathPattern))
    {
        xamlContent = Regex.Replace(xamlContent, wrongViewModelPathPattern, correctViewModelPath);
        File.WriteAllText(file, xamlContent); // Write the updated content back to the .xaml file
    }
}

// Process .xaml.cs files for correct ViewModel using statement
foreach (string file in viewCodeBehindFiles)
{
    string csContent = File.ReadAllText(file);
    string wrongUsingStatementPattern = @"using " + solutionName + "\\.Views\\.ViewModels;";
    string correctUsingStatement = "using " + solutionName + ".ViewModels;";

    // Replace wrong using statement if it's found
    if (Regex.IsMatch(csContent, wrongUsingStatementPattern))
    {
        csContent = Regex.Replace(csContent, wrongUsingStatementPattern, correctUsingStatement);
        File.WriteAllText(file, csContent); // Write the updated content back to the .xaml.cs file
    }
}

if (changesMade)
{
    File.WriteAllText(appShellFile, appShellFileContent);
}