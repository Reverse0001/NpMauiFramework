using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using $rootnamespace$.ViewModels;

namespace $rootnamespace$;


public partial class $safeitemname$ : ContentPage
{
	public $safeitemname$($safeitemname$Model vm)
	{
		InitializeComponent();
BindingContext = vm;
	}
}