using AsyncAwaitBestPractices;
using CommunityToolkit.Maui;
//Base usings
using $safeprojectname$.Services;
using $safeprojectname$.ViewModels;
using $safeprojectname$.Views;
using Microsoft.Extensions.Logging;

namespace $safeprojectname$
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder.UseMauiApp<App>().ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            })// Register Services and Views/ViewModels
            .RegisterServices().RegisterViewsAndViewModels().UseMauiCommunityToolkit();
            // Add Debug logging in development environment
#if DEBUG
            builder.Logging.AddDebug();
#endif
            return builder.Build();
        }

        private static MauiAppBuilder RegisterServices(this MauiAppBuilder builder)
        {
            // Register Services here
            // Example: builder.Services.AddTransient<MyService>();
            // Example: builder.Services.AddSingleton<IMyService, MyService>();

            return builder;
        }

        private static MauiAppBuilder RegisterViewsAndViewModels(this MauiAppBuilder builder)
        {
            // Register Views and ViewModels here
            // Example: builder.Services.AddTransient<MyViewModel>();

            return builder;
        }
    }
}