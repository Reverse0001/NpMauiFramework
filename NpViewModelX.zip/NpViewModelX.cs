﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommunityToolkit.Mvvm;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace $rootnamespace$
{
    public partial class $safeitemname$Model : ObservableObject
    {
        public $safeitemname$Model() { }
    }
}
